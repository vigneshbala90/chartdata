import React, { Component } from 'react';

export default class LoginForm extends Component {
    handleSignIn(e) {
        e.preventDefault();
        let username = this.refs.username.value;
        let password = this.refs.password.value;
        let priority = this.refs.priority.checked;
        localStorage.setItem('user', username);
        localStorage.setItem('pass', password);
        if (priority) {
            localStorage.setItem('priority', 'admin');
        } else {
            localStorage.setItem('priority', 'employee');
        }
        this.props.onSignIn(localStorage.getItem('user'), localStorage.getItem('pass'));
    }
    render() {
        return (
            <div className="container">
                <div className="row justify-content-md-center">
                    <div className="col-md-4">
                        <div className="rideForm">
                            <h3 className="my-4">Sign In Transport App</h3>
                            <form onSubmit={this.handleSignIn.bind(this)}>
                                <div className="form-group">
                                    <label>Email address</label>
                                    <input type="text" className="form-control" ref="username" placeholder="Enter Username" />
                                </div>
                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" className="form-control" ref="password" placeholder="Password" />
                                </div>
                                <div className="form-check">
                                    <input type="checkbox" className="form-check-input" ref="priority" id="priority" />
                                    <label className="form-check-label" htmlFor="priority">Admin</label>
                                </div>
                                <button type="submit" className="btn btn-primary my-3">Login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}