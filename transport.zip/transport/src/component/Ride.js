import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class Ride extends Component {
    constructor(props) {
        super(props)
        this.state = {
            search: '',
            data: [],
            dataDetails: ''
        }
    }
    componentDidMount() {
        fetch('http://localhost:5000/rides')
            .then(response => response.json())
            .then(data => {
                this.setState({
                    data: data
                })
            });
    }
    editRow = (editride) => {
        this.props.history.push('/editRide/' + editride);
    }
    delRow = (id) => {
        fetch('http://localhost:5000/rides/' + id, {
            method: 'DELETE'
        }).then(response => response.json())
            .then(data => {
                alert(data);
            });
        setTimeout(() => {
            document.location.reload(true);
        }, 1000);
    }
    filterText = (e) => {
        this.setState({
            search: e.target.value
        })
    }
    addPick = (val) => {
        var valsplit = val.split(' ').join('');
        fetch('http://localhost:5000/rides/pickdetails/' + valsplit)
            .then(response => response.json())
            .then(data => {
                this.setState({
                    dataDetails: data
                })
                /* alert(`Booked employees are: ${this.state.dataDetails.empID.map((a, i) => {
                    return a;
                })}`) */
            });
        //this.props.history.push('/addPick/' + val);
        //alert(this.state.dataDetails);
    }
    addEmp = (val) => {
        this.props.history.push('/addEmp/' + val);
        /* fetch('http://localhost:5000/rides/addEmp')
        .then(response => response.json())
        .then(data => {
            this.setState({
                dataDetails: data
            })
        }); */
        //this.props.history.push('/addPick/' + val);
        //alert(this.state.dataDetails);
    }
    dateConvert = (val) => {
        var date = new Date(val);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        return hours + ':' + minutes + ' ' + ampm;
    }
    render() {
        let filteredData = this.state.data.filter((data) => {
            return data.vhType.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1
        });
        return (
            <div className="ride-table my-4">
                <div className="form-inline">
                    <div className="form-group mb-4">
                        <label className="mr-3">Search</label>
                        <input type="text" value={this.state.search} onChange={this.filterText} />
                    </div>
                </div>
                <div className="col-lg-4 pl-0 mb-4">
                    <ul className="list-group">
                        {this.state.dataDetails.hasOwnProperty('empID') &&
                            <> 
                                <p className="mb-2">Booked Employees</p>
                                {this.state.dataDetails.empID.map((a, i) => {
                                    return <li key={a} className="list-group-item">{a}</li>;
                                })}
                            </>}
                    </ul>
                </div>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            {/* <th>Employee ID</th> */}
                            <th>Vehicle Type</th>
                            <th>Vehicle No</th>
                            <th>Total Seats</th>
                            <th>Time</th>
                            <th>Pick Up</th>
                            <th>Destination</th>
                            <th>Add Employees</th>
                            <th>Edit vehicle</th>
                            <th>Delete vehicle</th>
                            <th>Ride Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredData.map((a, i) => {
                            return <tr key={a.vhNum}>
                                {/* <td>{a.empID}</td> */}
                                <td>{a.vhType}</td>
                                <td>{a.vhNum}</td>
                                <td>{a.vhSeat === "" || a.vhSeat === undefined || a.vhSeat === null ? "Not Booked" : a.vhSeat === 0 || a.vhSeat < 0 ? "Book closed" : a.vhSeat}</td>
                                <td>{this.dateConvert(a.time)}</td>
                                <td>{a.pick}</td>
                                <td>{a.destination}</td>
                                <td><button type="button" disabled={a.vhSeat < 0 ? true : false} className="btn btn-primary btn-sm" onClick={() => this.addEmp(a._id)}>Add</button></td>
                                <td><button type="button" className="btn btn-warning btn-sm" onClick={() => this.editRow(a._id)}>Edit</button></td>
                                <td><button type="button" className="btn btn-danger btn-sm" onClick={() => this.delRow(a._id)}>Delete</button></td>
                                <td><button type="button" className="btn btn-primary btn-sm" onClick={() => this.addPick(a._id)}>Details</button></td>
                            </tr>
                        })}
                    </tbody>
                </table>
            </div>
        )
    }
}
export default withRouter(Ride);