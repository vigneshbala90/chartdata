import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class AddPick extends Component {
    constructor(props) {
        super(props)
        this.state = {
            empID: '',
            vhType: '',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        }
    }
    componentDidMount() {
        fetch('http://localhost:5000/rides/' + this.props.match.params.empID, {
            method: 'GET'
        }).then(res => res.json())
            .then(data => {
                this.setState({
                    empID: data.empID,
                    vhType: data.vhType,
                    vhNum: data.vhNum,
                    vhSeat: data.vhSeat,
                    time: data.time,
                    pick: data.pick,
                    destination: data.destination
                })
            })
    }
    dateConvert = (val) => {        
        var date = new Date(val);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0'+minutes : minutes;
        return hours + ':' + minutes + ' ' + ampm;
    }
    /* submitAddPick = (e) => {
        e.preventDefault();

        let { pickData } = this.state;
        if (pickData === "") {
            alert('Check all Fields are filled!');
        }
        else {
            fetch('http://localhost:5000/rides/' + '5e48700b64a26248ec4af476', {
                method: 'GET'
            }).then(res => res.json())
                .then(data => {
                    var date = new Date(data.time);
                    var hours = date.getHours();
                    var minutes = date.getMinutes();
                    var ampm = hours >= 12 ? 'pm' : 'am';
                    hours = hours % 12;
                    hours = hours ? hours : 12;
                    minutes = minutes < 10 ? '0' + minutes : minutes;
                    var strTime = hours + ':' + minutes + ' ' + ampm;
                    this.setState({
                        empID: data.empID,
                        vhType: data.vhType,
                        vhNum: data.vhNum,
                        vhSeat: data.vhSeat,
                        time: strTime,
                        pick: data.pick,
                        destination: data.destination
                    })
                })
        }
    }
    resetRide = () => {
        this.setState({
            empID: '',
            vhType: 'Bike',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: '',
            pickData: ''
        });
    } */
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-md-6">
                    <div className="rideForm">
                        <h3 className="text-center my-4">Pick Ride Confirmation</h3>                        
                        <table className="table table-striped table-bordered td-left-bg">
                            <tbody>
                                <tr>
                                    <th>Employee ID</th>
                                    <td>{this.state.empID}</td>
                                </tr>
                                <tr>
                                    <th>Vehicle Type</th>
                                    <td>{this.state.vhType}</td>
                                </tr>
                                <tr>
                                    <th>Vehicle No</th>
                                    <td>{this.state.vhNum}</td>
                                </tr>
                                <tr>
                                    <th>Vacant Seats</th>
                                    <td>{this.state.vhSeat}</td>
                                </tr>
                                <tr>
                                    <th>Time</th>
                                    <td>{this.dateConvert(this.state.time)}</td>
                                </tr>
                                <tr>
                                    <th>Pick Up</th>
                                    <td>{this.state.pick}</td>
                                </tr>
                                <tr>
                                    <th>Destination</th>
                                    <td>{this.state.destination}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
                )
            }
        }
        export default withRouter(AddPick);
