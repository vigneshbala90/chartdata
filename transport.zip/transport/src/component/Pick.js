import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class Pick extends Component {
    constructor(props) {
        super(props)
        this.state = {
            search: '',
            data: []
        }
    }
    componentDidMount() {
        fetch('http://localhost:5000/rides')
        .then(response => response.json())
        .then(data => {
            this.setState({
                data: data
            })
        });
    }
	editRow = (editride) => {
		this.props.history.push('/editRide/' + editride);
	}
	delRow = (id) => {
		fetch('http://localhost:5000/rides/' + id, {
			method: 'DELETE'
        }).then(response => response.json())        
        .then(data => {
            alert(data);
        });
        setTimeout(() => {
            document.location.reload(true);
        }, 1000);
	}
    filterText = (e) => {
        this.setState({
            search: e.target.value
        })
    }
    addPick = (val, valvhSeat, valEmp) => {
        console.log(val);
        let pickConfirm = window.confirm('Are you confirm this ride?');
        if(pickConfirm) {
            fetch('http://localhost:5000/rides/pickok/' + val, {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({
                    vhSeat: valvhSeat - 1,
                    empName: localStorage.getItem('user')
                })
            })
                .then(response => response.json())
                .then((data) => alert(data))
        } else {
            alert('Ride Cancel');
        }
        setTimeout(() => {
            document.location.reload(true);
        }, 1000);
    }
    dateConvert = (val) => {
        var date = new Date(val);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0'+minutes : minutes;
        return hours + ':' + minutes + ' ' + ampm;
    }
    render() {
        let filteredData = this.state.data.filter((data) => {
            return data.vhType.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1
        });
        return (
            <div className="ride-table my-4">
                <div className="form-inline">
                    <div className="form-group mb-4">
                        <label className="mr-3">Search</label>                        
                        <input type="text" value={this.state.search} onChange={this.filterText} />
                    </div>
                </div>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Vehicle Type</th>
                            <th>Vehicle No</th>
                            <th>Seat Availability</th>
                            {/* <th>Seat</th> */}
                            <th>Time</th>
                            <th>Pick Up</th>
                            <th>Destination</th>
                            <th>Pick Ride</th>
                        </tr>
                    </thead>
                    <tbody>                        
                            {filteredData.map((a, i) => {
                                //let seatSame = a.vhSeatAv = a.vhSeat
                                return <tr key={a.empID}>
                                    <td>{a.vhType}</td>
                                    <td>{a.vhNum}</td>
                                    <td>{a.vhSeat === "" || a.vhSeat === undefined || a.vhSeat === null ? "Not Booked" : a.vhSeat === 0 ? "Book closed" : a.vhSeat}</td>
                                    {/* <td>{a.vhSeatAv === "" || a.vhSeatAv === undefined || a.vhSeatAv === null ? "Not Booked" : a.vhSeatAv}</td>
                                    <td>{seatSame === seatSame ? "Not Booked" : a.vhSeatAv}</td> */}
                                    <td>{this.dateConvert(a.time)}</td>
                                    <td>{a.pick}</td>
                                    <td>{a.destination}</td>                                    
                                    <td><button type="button" disabled={a.vhSeat > 0 || a.vhSeat === "" || a.vhSeat === undefined || a.vhSeat === null ? false : true} className="btn btn-primary btn-sm" onClick={() => this.addPick(a._id, a.vhSeat, a.empID)}>Pick Ride</button></td>
                                </tr>
                            })}
                    </tbody>
                </table>
            </div>
        )
    }
}
export default withRouter(Pick);