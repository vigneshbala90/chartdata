import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { withRouter } from 'react-router-dom';

class AddRide extends Component {
    constructor(props) {
        super(props)
        this.state = {
            /* empID: '', */
            vhType: '',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        }
    }
    rideChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }
    rideDateChange = (val) => {
        this.setState({
            time: val
        });
    }
    dateConvert = (val) => {
        var date = new Date(val);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        return hours + ':' + minutes + ' ' + ampm;
    }
    submitRide = (e) => {
        e.preventDefault();
        let { vhType, vhNum, vhSeat, time, pick, destination } = this.state;
        if (vhType === "" || vhNum === "" || vhSeat === "" || time === "" || pick === "" || destination === "") {
            alert('Check all Fields are filled!');
        }
        else {
            fetch('http://localhost:5000/rides/add', {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({
                    vhType: this.state.vhType,
                    vhNum: this.state.vhNum,
                    vhSeat: this.state.vhSeat,
                    time: this.state.time,
                    pick: this.state.pick,
                    destination: this.state.destination
                })
            })
                .then(response => response.json())
                .then((data) => alert(data))
                .then(() => this.props.history.push('/'));
            /* var rideVal = {
                "empID": this.state.empID,
                "vhType": this.state.vhType,
                "vhNum": this.state.vhNum,
                "vhSeat": this.state.vhSeat,
                "time": strTime,
                "pick": this.state.pick,
                "destination": this.state.destination
            }
            if (localStorage) {
                var ridedt;
                if (!localStorage['emp']) ridedt = [];
                else ridedt = JSON.parse(localStorage['emp']);            
                if (!(ridedt instanceof Array)) ridedt = [];
                ridedt.push(rideVal);
        
                localStorage.setItem('emp', JSON.stringify(ridedt));
            } 
            console.log(JSON.stringify({
                "empID": this.state.empID,
                "vhType": this.state.vhType,
                "vhNum": this.state.vhNum,
                "vhSeat": this.state.vhSeat,
                "time": strTime,
                "pick": this.state.pick,
                "destination": this.state.destination
            })); */
        }
    }
    resetRide = () => {
        this.setState({
            vhType: 'Bike',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        });
    }
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-md-6">
                    <div className="rideForm">
                        <h3 className="text-center my-4">Add Ride</h3>
                        <form onSubmit={this.submitRide}>
                            {/* <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Employee ID</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="empID" value={this.state.empID} onChange={this.rideChange} /></div>
                            </div> */}
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vehicle Type</label>
                                <div className="col-sm-9"><select className="form-control" name="vhType" value={this.state.vhType} onChange={this.rideChange}>
                                    <option value="">Select Type</option>
                                    <option value="Bike">Bike</option>
                                    <option value="Suv">Suv</option>
                                    <option value="Car">Car</option>
                                    <option value="TT">TT</option>
                                </select>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vehicle No</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="vhNum" value={this.state.vhNum} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vacant Seats</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="vhSeat" value={this.state.vhSeat} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Shift Time</label>
                                <div className="col-sm-9">
                                    <DatePicker
                                        selected={this.state.time}
                                        onChange={this.rideDateChange}
                                        className="form-control"
                                        name="time"
                                        showTimeSelect
                                        showTimeSelectOnly
                                        timeIntervals={15}
                                        timeCaption="Time"
                                        dateFormat="h:mm aa"
                                    /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Pick Up</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="pick" value={this.state.pick} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Destination</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="destination" value={this.state.destination} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group text-center mt-4">
                                <button type="submit" className="btn btn-primary">Save</button>
                                <button type="reset" className="btn btn-secondary ml-2" onClick={this.resetRide}>Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}
export default withRouter(AddRide);