import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class AddEmp extends Component {
    constructor(props) {
        super(props)
        this.state = {
            empID: [],
            empVal: '',
            vhType: '',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        }
    }
    componentDidMount() {
        fetch('http://localhost:5000/rides/' + this.props.match.params.empID, {
            method: 'GET'
        }).then(res => res.json())
            .then(data => {
                this.setState({
                    vhType: data.vhType,
                    vhNum: data.vhNum,
                    vhSeat: data.vhSeat,
                    time: data.time,
                    pick: data.pick,
                    destination: data.destination
                })
            })
    }
    dateConvert = (val) => {
        var date = new Date(val);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        return hours + ':' + minutes + ' ' + ampm;
    }
    empChange = (val) => {
        this.setState({
            empVal: val.target.value
        })
    }
    submitEmp = () => {
        let { empID } = this.state;
        if (empID === "") {
            alert('Check all Fields are filled!');
        }
        else {
            const currentEmp = this.state.empID;
            const empInput = this.state.empVal;
            if (currentEmp.includes(empInput) === false) {
                let newEmp = currentEmp.concat(this.state.empVal);
                this.setState({ empID: newEmp }, function () {
                    fetch('http://localhost:5000/rides/addEmp/' + this.props.match.params.empID, {
                        method: 'POST',
                        headers: { 'content-type': 'application/json' },
                        body: JSON.stringify({
                            empID: this.state.empID,
                            vhSeat: this.state.vhSeat - this.state.empID.length,
                        })
                    })
                        .then(response => response.json())
                        .then((data) => alert(data));
                });

            } else {
                alert('This employee ID is already scheduled');
            }
        }
    }
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-md-6">
                    <div className="rideForm">
                        <h3 className="text-center my-4">Pick Ride Confirmation</h3>
                        <table className="table table-striped table-bordered td-left-bg">
                            <tbody>
                                <tr>
                                    <th>Employee ID</th>
                                    <td><input type="text" className="form-control" readOnly={this.state.vhSeat < 0 ? true : false} value={this.state.empVal} onChange={this.empChange} /></td>
                                </tr>
                                <tr>
                                    <th>Vehicle Type</th>
                                    <td>{this.state.vhType}</td>
                                </tr>
                                <tr>
                                    <th>Vehicle No</th>
                                    <td>{this.state.vhNum}</td>
                                </tr>
                                <tr>
                                    <th>Vacant Seats</th>
                                    <td>{this.state.vhSeat < 0 ? "Seats Closed" : this.state.vhSeat}</td>
                                </tr>
                                <tr>
                                    <th>Time</th>
                                    <td>{this.dateConvert(this.state.time)}</td>
                                </tr>
                                <tr>
                                    <th>Pick Up</th>
                                    <td>{this.state.pick}</td>
                                </tr>
                                <tr>
                                    <th>Destination</th>
                                    <td>{this.state.destination}</td>
                                </tr>
                                <tr>
                                    <th>&nbsp;</th>
                                    <td><button disabled={this.state.vhSeat < 0 ? true : false} onClick={this.submitEmp} type="button" className="btn btn-primary btn-sm">Add Employee</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        )
    }
}
export default withRouter(AddEmp);
