import React from 'react';
export const Welcome = ({ user, onSignOut }) => {
    // This is a dumb "stateless" component
    return (
        <>
            Welcome {localStorage.getItem('priority') === 'admin' && "Admin "}<strong>{localStorage.getItem('user')}</strong>! <span className="text-info cp" onClick={onSignOut}>Sign out</span>
        </>
    )
}