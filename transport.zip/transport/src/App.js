import React, { Component, Suspense, lazy } from 'react';
import AddRide from './component/AddRide';
import EditRide from './component/EditRide';
import Pick from './component/Pick';
import PickRide from './component/PickRide';
import LoginForm from './component/LoginForm';
import { Welcome } from './component/Welcome';
import AddEmp from './component/AddEmp';
import { BrowserRouter, Route, Switch, Link, NavLink } from "react-router-dom";

const Ride = lazy(() => import('./component/Ride'));

export default class App extends Component {
	constructor(props) {
		super(props)
		this.state = {
			user: null
		}
	}
	signIn(username, password) {
		console.log(username, password);
		this.setState({
			user: {
				username,
				password
			}
		})
	}
	signOut() {
        localStorage.removeItem('user');
        localStorage.removeItem('pass');
        localStorage.removeItem('priority');
        setTimeout(() => {
            document.location.reload(true);
        }, 500);
	}
	render() {
		return (
			<div className="App">
				{
					(localStorage.getItem('priority') === 'admin' || localStorage.getItem('priority') === 'employee')  ?
						<>	
							<BrowserRouter>
								<nav className="navbar navbar-expand-lg navbar-light bg-light">
									<Link className="navbar-brand" to="/">Transport</Link>
									<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navdata" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
										<span className="navbar-toggler-icon"></span>
									</button>
									<div className="collapse navbar-collapse" id="navdata">
										<ul className="navbar-nav ml-auto">
											{localStorage.getItem('priority') === 'admin' && 
											<>
											<li className="nav-item">
												<NavLink exact to="/" activeclass="active" className="nav-link">Ride</NavLink>
											</li>
											<li className="nav-item">
												<NavLink to="/addRide" activeclass="active" className="nav-link">Add Ride</NavLink>
											</li>
											<li className="nav-item">
												<p className="p-2"><Welcome user={this.state.user} onSignOut={this.signOut.bind(this)} /></p>
											</li>
											</>}											
											{localStorage.getItem('priority') === 'employee' && 
											<>
											<li className="nav-item">
												<NavLink to="/pick" activeclass="active" className="nav-link">Pick</NavLink>
											</li>
											<li className="nav-item">
												<p className="p-2"><Welcome user={this.state.user} onSignOut={this.signOut.bind(this)} /></p>
											</li>
											</>}
										</ul>
									</div>
								</nav>
								<div className="container">
									<div className="row">
										<div className="col-lg-12">
											<Switch>
											{localStorage.getItem('priority') === 'admin' && 
												<>
													<Route exact path="/" component={() => <Suspense fallback={<div>Loading...</div>}>
														<Ride />
													</Suspense>} />
													<Route path="/addRide" component={() => <AddRide />} />
													<Route path="/editRide/:empID" component={() => <EditRide />} />
													<Route path="/addEmp/:empID" component={() => <AddEmp />} />
												</> }
											{localStorage.getItem('priority') === 'employee' && 
												<>
												<Route exact path="/" component={() => <Pick />} />
												<Route path="/pickRide/:empID" component={() => <PickRide />} />
												</> }
											</Switch>
										</div>
									</div>
								</div>
							</BrowserRouter>
						</> :
							<LoginForm onSignIn={this.signIn.bind(this)} />
				}
			</div>
		)
	}
}
