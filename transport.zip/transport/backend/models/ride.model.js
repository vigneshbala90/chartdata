const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const rideSchema = new Schema({
    empID: { type: Object, trim: true, minlength: 3 },
    vhType: { type: String, required: true, trim: true },
    vhNum: { type: String, required: true, unique: true, trim: true },
    vhSeat: { type: String, required: true, trim: true },
    time: { type: String, required: true, trim: true },
    pick: { type: String, required: true, trim: true },
    destination: { type: String, required: true, trim: true }
}, {
    timestamps: true
});

const Ride = mongoose.model('ride', rideSchema);

module.exports = Ride;