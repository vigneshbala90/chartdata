const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
var url = "mongodb+srv://vignesh:Mongo123@cluster0-ovqlu.gcp.mongodb.net/transport?retryWrites=true&w=majority";
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

mongoose.connect(url, { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true, useFindAndModify: true });
const connection = mongoose.connection;
connection.once('open', () => {
    console.log("MongoDB database connection established successfully");
});

const rideRouter = require('./routes/rides');
app.use('/rides', rideRouter);

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});