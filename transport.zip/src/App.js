import React, { Component, Suspense, lazy } from 'react';
import AddRide from './component/AddRide';
import EditRide from './component/EditRide';
import PickRide from './component/PickRide';
import { BrowserRouter, Route, Switch, Link, NavLink } from "react-router-dom";

const Ride = lazy(() => import('./component/Ride'));

export default class App extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }
  render() {
    return (
      <div className="App">
      <BrowserRouter>
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
              <Link className="navbar-brand" to="/">Transport</Link>
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navdata" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navdata">
                <ul className="navbar-nav ml-auto">
                  <li className="nav-item">
                    <NavLink exact to="/" activeclass="active" className="nav-link">Ride</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink to="/addRide" activeclass="active" className="nav-link">Add Ride</NavLink>
                  </li>
                </ul>
              </div>
            </nav>
            <Switch>
                <Route exact path="/" component={() => <Suspense fallback={<div>Loading...</div>}>
        <Ride />
      </Suspense>} />
                <Route path="/addRide" component={() => <AddRide />} />
                <Route path="/editRide" component={() => <EditRide />} />
                <Route path="/pickRide" component={() => <PickRide />} />
                </Switch>
            </div>
          </div>
        </div>
            </BrowserRouter>
      </div>
    )
  }
}
