import React, { Component } from 'react';

export default class Ride extends Component {
    constructor(props) {
        super(props)
        this.state = {
            search: '',
            data: JSON.parse(localStorage.emp)
        }
    }
    componentDidMount() {
        /* fetch('http://my-json-server.typicode.com/vigneshbala90/chartdata/posts/')
        .then(response => response.json())
        .then(data => {
            this.setState({
                data: data
            })
        }) */
    }
    /* deleteData = (val) => {
        console.log(val);
        var arr = [...this.state.data];
        var index = arr.indexOf(val)
        if (index !== -1) {
            arr.splice(index, 1);
            this.setState({data: arr});
        }
    } */
    filterText = (e) => {     
        this.setState({
            search: e.target.value
        })
        console.log(this.state.data);
    }
    pickRide = (val) => {
        alert(`This ride is picked by: Employee ID - ${val}`);
    }
    render() {   
        let filteredData = this.state.data.filter((data) => {
            return data.vhType.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1
        });
        console.log(filteredData);
        return (
            <div className="ride-table my-4">
                <div className="form-inline">
                    <div className="form-group mb-4">
                        <label className="mr-3">Search</label>                        
                        <input type="text" value={this.state.search} onChange={this.filterText} />
                    </div>
                </div>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Vehicle Type</th>
                            <th>Vehicle No</th>
                            <th>Vacant Seats</th>
                            <th>Time</th>
                            <th>Pick Up</th>
                            <th>Destination</th>
                            <th>Pick Ride</th>
                            {/* <th>Delete</th> */}
                        </tr>
                    </thead>
                    <tbody>                        
                            {filteredData.map((a, i) => {
                                return <tr key={a.empID}>
                                    <td>{a.empID}</td>
                                    <td>{a.vhType}</td>
                                    <td>{a.vhNum}</td>
                                    <td>{a.vhSeat}</td>
                                    <td>{a.time}</td>
                                    <td>{a.pick}</td>
                                    <td>{a.destination}</td>
                                    <td><button type="button" className="btn btn-primary" onClick={() => this.pickRide(a.empID)}>Pick Ride</button></td>
                                    {/* <td><button type="button" className="btn btn-warning" onClick={() => this.deleteData(a.empID)}>Delete</button></td> */}
                                </tr>
                            })}
                    </tbody>
                </table>
            </div>
        )
    }
}
