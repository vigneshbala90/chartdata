import React, { Component } from 'react';
import DatePicker from "react-datepicker"; 
import "react-datepicker/dist/react-datepicker.css";

export default class Ride extends Component {
    constructor(props) {
        super(props)
        this.state = {
            empID: '',
            vhType: 'Bike',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        }
    }
    rideChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }    
    rideDateChange = (val) => {
        this.setState({
            time: val
        });
    }
    submitRide = (e) => {     
        let arrobj = [{"empID": "190",
        "vhType": "Bike",
        "vhNum": "tn 59",
        "vhSeat": "5",
        "time": "4:45 pm",
        "pick": "madivala",
        "destination": "bangalore"},{"empID": "190",
        "vhType": "Bike",
        "vhNum": "tn 59",
        "vhSeat": "5",
        "time": "4:45 pm",
        "pick": "madivala",
        "destination": "bangalore"},{"empID": "120",
        "vhType": "Bike",
        "vhNum": "tn 59",
        "vhSeat": "5",
        "time": "4:45 pm",
        "pick": "madivala",
        "destination": "bangalore"}]   
        /* let arrayval = JSON.parse(localStorage.emp);
        let uniqempID = arrobj.filter((val, index, self) => {
            if(self.includes(val.empID) != val.empID) {
                alert('not Unique');
            } else {
                alert('Unique');
            }
        }); 
        console.log(uniqempID); */
        var date = new Date(this.state.time);
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        let { empID, vhType, vhNum, vhSeat, time, pick, destination } = this.state;
        if(empID  === "" || vhType  === "" || vhNum  === "" || vhSeat  === "" || time  === "" || pick  === "" || destination === "" ) {
            alert('Check all Fields are filled!');
        }
            else {
        /* fetch('http://my-json-server.typicode.com/vigneshbala90/chartdata/posts/', {
            method: 'POST',
            body: JSON.stringify({
                "empID": this.state.empID,
                "vhType": this.state.vhType,
                "vhNum": this.state.vhNum,
                "vhSeat": this.state.vhSeat,
                "time": this.state.time,
                "pick": this.state.pick,
                "destination": this.state.destination
            }),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        })
        .then(response => response.json())
        .then(data => console.log(data)); */
        
        var rideVal = {
            "empID": this.state.empID,
            "vhType": this.state.vhType,
            "vhNum": this.state.vhNum,
            "vhSeat": this.state.vhSeat,
            "time": strTime,
            "pick": this.state.pick,
            "destination": this.state.destination
        }
        if (localStorage) {
            var ridedt;
            if (!localStorage['emp']) ridedt = [];
            else ridedt = JSON.parse(localStorage['emp']);            
            if (!(ridedt instanceof Array)) ridedt = [];
            ridedt.push(rideVal);
    
            localStorage.setItem('emp', JSON.stringify(ridedt));
        } 
        console.log(JSON.stringify({
                "empID": this.state.empID,
                "vhType": this.state.vhType,
                "vhNum": this.state.vhNum,
                "vhSeat": this.state.vhSeat,
                "time": strTime,
                "pick": this.state.pick,
                "destination": this.state.destination
            }));
        }        
        e.preventDefault();
    }
    resetRide = () => {
        this.setState({
            empID: '',
            vhType: 'Bike',
            vhNum: '',
            vhSeat: '',
            time: '',
            pick: '',
            destination: ''
        });
    }
    render() {
        return (
            <div className="row justify-content-md-center">
                <div className="col-md-6">
                    <div className="rideForm">
                        <h3 className="text-center my-4">Add Ride</h3>
                        <form onSubmit={this.submitRide}>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Employee ID</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="empID" value={this.state.empID} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vehicle Type</label>
                                <div className="col-sm-9"><select className="form-control" name="vhType" value={this.state.vhType} onChange={this.rideChange}>
                                    <option value="Bike">Bike</option>
                                    <option value="Car">Car</option>
                                </select>
                                </div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vehicle No</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="vhNum" value={this.state.vhNum} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Vacant Seats</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="vhSeat" value={this.state.vhSeat} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Time</label>
                                <div className="col-sm-9">
                                <DatePicker
                                    selected={this.state.time}
                                    onChange={this.rideDateChange}
                                    className="form-control"
                                    name="time"
                                    showTimeSelect
                                    showTimeSelectOnly
                                    timeIntervals={15}
                                    timeCaption="Time"
                                    dateFormat="h:mm aa"
                                    /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Pick Up</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="pick" value={this.state.pick} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group row">
                                <label className="col-sm-3 col-form-label">Destination</label>
                                <div className="col-sm-9"><input type="text" className="form-control" name="destination" value={this.state.destination} onChange={this.rideChange} /></div>
                            </div>
                            <div className="form-group text-center mt-4">
                                <button type="submit" className="btn btn-primary">Save</button>
                                <button type="reset" className="btn btn-secondary ml-2" onClick={this.resetRide}>Reset</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }
}
