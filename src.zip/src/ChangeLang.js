import React from "react";
import { withTranslation } from "react-i18next";

const ChangeLang = ({ i18n }) => {
  return (
    <div>
      <button onClick={() => i18n.changeLanguage("de")}>de</button>
      <button onClick={() => i18n.changeLanguage("en")}>en</button>
    </div>
  );
};

// extended main view with withTranslation hoc
export default withTranslation("translations")(ChangeLang);
