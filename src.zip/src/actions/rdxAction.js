import { NAMEACTION, APICALL, AUTHORNAME } from './types';
export const rdxAction = (value) => {
    return {
        type: NAMEACTION,
        payload: value
    }
}
export const rdxApi = (pagval) => {
    return (dispatch) => {
        fetch('http://localhost:5000/products/?pagevalue='+pagval)
            .then(res => res.json())
            .then(data => {
                    dispatch({
                        type: APICALL,
                        payload: data
                    })
                })
            .catch(error => console.log(error));
            //.finally(() => console.log('Api works'));
    }
}
export const authorAct = (value) => {
    return {
        type: AUTHORNAME,
        payload: value
    }
    /*return (dispatch) => {
        fetch('', {
            headers: { 'content-type' : 'application/json'},
            body: formData,
            method: 'POST'
        }).then(res => res.json())
        .then(data => console.log(data));
    }*/
}