import { NAMEACTION, APICALL, AUTHORNAME } from '../actions/types';
const intialState = {
    rdxName: 'vignesh bala',
    products: [],
    authorName: 'Vignesh'
};

const rdxReducer = (state = intialState, action) => {
    switch (action.type) {
        case NAMEACTION:
            return {
                ...state,
                rdxName: action.payload
            }
        case APICALL:
            return {
                ...state,
                products: action.payload,
                //rdxName: state.hi
            }
            case AUTHORNAME:
                return {
                    ...state,
                    authorName: action.payload
                }
        default:
            return state
    }
}
export default rdxReducer;