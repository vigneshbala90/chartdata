import { combineReducers } from "redux";
import authReducer from "./authReducer";
import errorReducer from "./errorReducer";
import rdxReducer from './rdxReducer';

export default combineReducers({
  auth: authReducer,
  errors: errorReducer,
  rdx: rdxReducer,
});
