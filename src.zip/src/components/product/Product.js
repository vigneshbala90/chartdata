import React, { Component } from "react";
import { connect } from 'react-redux';
import { rdxAction, rdxApi, authorAct } from '../../actions/rdxAction';
import { Container, Row, Col, Table } from 'react-bootstrap';

class Product extends Component {
	constructor(props) {
		super(props)
		this.state = {
			products: [],
			productsEdit: [],
			search: '',
			chkRedux: null,
			name: '',
			pass: ''
		}
		this.editRow = this.editRow.bind(this);
		this.delRow = this.delRow.bind(this);
		this.inputRef = React.createRef();
	}
	componentDidMount() {
		/* fetch('https://jsonplaceholder.typicode.com/users').then(res => res.json())
			.then(data => {
				this.setState({
					products: data
				})
					.catch(error => console.log(error))
					.finally(() => console.log('Api works'));
			}); */
		//this.props.rdxapi();
		this.props.rdxApi(5);
	}
	editRow = (editproduct) => {
		this.props.history.push('/edit/' + editproduct._id);
	}
	delRow = (id) => {
		// var index = this.props.rdxProduct.indexOf(e);
		// this.props.rdxProduct.splice(index, 1);
		// this.setState(this.props.rdxProduct);
		fetch('http://localhost:5000/products/' + id._id, {
			method: 'DELETE'
		}).then(response => response.json())
			.then(data => console.log(data));
	}
	searchchange = (e) => {
		this.setState({
			search: e.target.value
		});
	}
	changeData = (event) => {
		this.setState({
			[event.target.name]: event.target.value
		});
	}
	submithandler = (e) => {
		console.log(e);
		fetch('https://jsonplaceholder.typicode.com/users', {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				name: this.state.name,
				pass: this.state.pass
			})
		})
			.then(res => res.json())
			.then(data => console.log(data))
			.catch(error => console.log(error))
			.finally(() => console.log('Api works'));
		e.preventDefault();
	}
	handleBtn = e => {
		//this.props.rdxaction(e.target.textContent);
		this.props.rdxAction(e.target.textContent);
	}
	refChange = e => {

	}
	render() {
		let filtertext = this.props.rdxProduct.filter(product => {
			if (product.prodName.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1) {
				return product;
			}
			return null;
		});
		return (
			<div className="product product-list">
				<Container fluid>
					<Row>
						<Col>
						{/* <Controls /> */}
							{/* <input type='text' ref={this.inputRef} />
							<br />
							Redux value : {this.props.rdxname} &nbsp;
							<button onClick={this.handleBtn}>change value</button>
							<br /> 
							Search: <input type='text' value={this.state.search} onChange={this.searchchange} ref={this.inputRef} />
							<p>{this.state.search}</p>
							AuthorName: {this.props.rdxAuthor} */}
							<Table responsive striped bordered hover size="sm">
								<thead>
									<tr>
										{/* <th>Id</th> */}
										<th>Product Name</th>
										<th>Stock</th>
										<th>Type</th>
										<th>Edit</th>
										<th>Delete</th>
									</tr>
								</thead>
								<tbody>
									{filtertext.map(items => {
										return <React.Fragment key={items._id}>
											<tr>
												{/* <td>{items._id}</td> */}
												<td>{items.prodName}</td>
												<td>{items.prodStock}</td>
												<td>{items.prodDesc}</td>
												<td><button onClick={(e) => this.editRow(items)}>Edit</button></td>
												<td><button onClick={(e) => this.delRow(items)}>Delete</button></td>
											</tr>
										</React.Fragment>
									})}
								</tbody>
							</Table>
							{/*<p>
								{this.state.productsEdit.map(items => {
									return <React.Fragment key={items.id}>
										Name: {items.name} <br />
										Email: {items.email}
									</React.Fragment>
								})}
								<br />
							</p>
							<form onSubmit={this.submithandler}>
								<input type='text' name='name' value={this.state.name} onChange={this.changeData} />
								<input type='text' name='pass' value={this.state.pass} onChange={this.changeData} />
								<button type='submit'>submit</button>
							</form>*/}
						</Col>
					</Row>
				</Container>
			</div>
		)
	}
}
const mapStateToProps = (state) => {
	return {
		rdxname: state.rdx.rdxName,
		rdxProduct: state.rdx.products,
		rdxAuthor: state.rdx.authorName
	}
}

/* const mapDispatchToProps = dispatch => {
	return {
		rdxaction: (params) => {
			dispatch(rdxAction(params))
		},
		rdxapi: () => {
			dispatch(rdxApi())
		},
		authorAct: () => {
			dispatch(authorAct())
		}
	};
}; */
export default connect(mapStateToProps, { authorAct, rdxApi, rdxAction })(Product);
//export default connect(mapStateToProps, mapDispatchToProps)(Product);