import React, { Component } from "react";
import { Form, Row, Col, Button } from 'react-bootstrap';

class ProductCreate extends Component {
	constructor(props) {
		super(props)
		this.state = {
			prodname: '',
			stock: '',
			desc: '',
			date: ''
		}
	}
	submithandler = (e) => {;
		fetch('http://localhost:5000/products/add', {
			method: 'POST',
			headers: { 'content-type': 'application/json' },
			body: JSON.stringify({
				prodName: this.state.prodname,
				prodStock: this.state.stock,
				prodDesc: this.state.desc,
				date: this.state.date
			})
		})	
			.then(res => res.json())
			.then(data => console.log(data))
			.catch(error => console.log(error))
			.finally(() => console.log('Api works'));
		this.clearData();
		e.preventDefault();
	}
	changeData = (event) => {
		this.setState({
			[event.target.name]: event.target.value
		});
	}
	clearData = () => {
		this.setState({
			prodname: '',
			stock: '',
			desc: '',
			date: ''
		});
	}
	render() {
		console.log(this.state.date);
		return (
			<div className="product product-create">
				<Col>
					<Form onSubmit={this.submithandler}>
						<Form.Group as={Row} controlId="prodname">
							<Form.Label column sm="2">Product Name</Form.Label>
							<Col sm="10">
								<Form.Control type='text' name='prodname' value={this.state.prodname} onChange={this.changeData} />
							</Col>
						</Form.Group>
						<Form.Group as={Row} controlId="stock">
							<Form.Label column sm="2">Stock</Form.Label>
							<Col sm="10">
								<Form.Control type='text' name='stock' value={this.state.stock} onChange={this.changeData} />
							</Col>
						</Form.Group>
						<Form.Group as={Row} controlId="description">
							<Form.Label column sm="2">Description</Form.Label>
							<Col sm="10">
								<Form.Control type='text' name='desc' value={this.state.desc} onChange={this.changeData} />
							</Col>
						</Form.Group>
						<Form.Group as={Row} controlId="date">
							<Form.Label column sm="2">Date</Form.Label>
							<Col sm="10">
								<Form.Control type='date' name='date' value={this.state.date} onChange={this.changeData} />
							</Col>
						</Form.Group>
						<Button variant="primary" type="submit">Submit</Button>
					</Form>
				</Col>
			</div>
		)
	}
}
export default ProductCreate;